#!/system/bin/sh
MODDIR=${0%/*}

(
until [ $(getprop sys.boot_completed) -eq 1 ] ; do
  sleep 5
done
export PATH="/system/bin:/system/xbin:/vendor/bin:$(magisk --path)/.magisk/busybox:$PATH"
crond -c $MODDIR/cron

#777权限
chmod 777 /data/adb/modules/Tricky_store-bm/Whitelist520/*
sh /data/adb/modules/Tricky_store-bm/Whitelist520/独断万古.sh
rm -rf /data/adb/modules/Tricky_store-bm/update
am force-stop icu.nullptr.nativetest >/dev/null 2>&1 &
rm -rf /storage/emulated/0/*.img

#resetprop -n ro.boot.vbmeta.digest 

sleep 30

sp="/data/adb/tricky_store/security_patch.txt"
current_year=$(date +%Y)
current_month=$(date +%m | sed 's/^0*//')

if [ "$current_month" -eq 1 ]; then  # 如果是1月
    prev_month=12                    # 上个月是12月
    prev_year=$((current_year - 1))  # 年份减1
else
    prev_month=$((current_month - 1))  # 否则月份减1
    prev_year=$current_year            # 年份不变
fi

formatted_month=$(printf "%02d" $prev_month)

echo "all=${prev_year}-${formatted_month}-05" > "$sp"
)