#!/bin/sh

echo ""
echo -e "                  TG频道：@Whitelist520"
sleep 1s
echo -ne '                     □□□□□□□□□□0% '
sleep 0.1
echo -ne '                     ■■■■■■■■■■100% '
sleep 0.1

    echo ""
    echo "😔红线划过深藏轮回的秘密"
    echo "😭我挥霍运气"
    echo "💔因为你才让我背对命运不害怕"
    
    sleep 1
    echo ""
    echo "- - - - - - - - - -"
    echo "下方仅显示5个包名"
    echo "代表更新成功了哦~"
    echo "- - - - - - - - - -"
    echo ""


sh -c /data/adb/modules/Tricky_store-bm/Whitelist520/独断万古.sh

head -n 5 /data/adb/tricky_store/target.txt


sleep 2

