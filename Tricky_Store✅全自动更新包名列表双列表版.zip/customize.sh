#!/system/bin/sh

if [ ! -d "/data/adb/modules/tricky_store" ]; then
  ui_print "  你没有安装Tricky Store模块！"
  ui_print "  请安装Tricky Store模块后安装此模块！"
  exit 1
fi  

echo "  这一纪元，我独断万古！✊"
sleep 3
am start -a android.intent.action.VIEW -d tg://resolve?domain=Whitelist520 >/dev/null 2>&1
echo " " >/data/adb/modules/Tricky_store-bm/update