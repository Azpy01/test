#!/system/bin/sh

echo "  天下万般绝学，莫过恒心✊"
sleep 3
am start -a android.intent.action.VIEW -d tg://resolve?domain=Whitelist520 >/dev/null 2>&1
echo " " >/data/adb/modules/AP_AutoExclude/update